package com.cg.sprint2.transferamount.ms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransferAmountApplicationTests {

	@Test
	void contextLoads() {
	}

}
