package com.cg.sprint2.showbalance.ms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShowBalanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
